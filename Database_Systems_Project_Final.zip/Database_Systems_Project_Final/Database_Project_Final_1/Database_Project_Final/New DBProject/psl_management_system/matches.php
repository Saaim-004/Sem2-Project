<?php

session_start();
include 'includes/connect.php';

$is_admin = isset($_SESSION['admin_id']);

$upcoming_sql = "SELECT m.*, t1.team_name AS team1_name, t2.team_name AS team2_name
                 FROM matches m
                 INNER JOIN teams t1 ON m.team1_id = t1.team_id
                 INNER JOIN teams t2 ON m.team2_id = t2.team_id
                 WHERE m.winner_id IS NULL
                 ORDER BY m.match_date ASC";
$upcoming = $conn->query($upcoming_sql);

$completed_sql = "SELECT m.*, t1.team_name AS team1_name, t2.team_name AS team2_name,
                         w.team_name AS winner_name
                  FROM matches m
                  INNER JOIN teams t1 ON m.team1_id = t1.team_id
                  INNER JOIN teams t2 ON m.team2_id = t2.team_id
                  LEFT JOIN teams w  ON m.winner_id = w.team_id
                  WHERE m.winner_id IS NOT NULL
                  ORDER BY m.match_date DESC";
$completed = $conn->query($completed_sql);
?>
<?php include 'includes/header.php'; ?>

<h2 class="page-title">Matches</h2>

<?php if (isset($_GET['msg'])) { ?>
    <div class="msg msg-success"><?php echo $conn->real_escape_string($_GET['msg']); ?></div>
<?php } ?>

<?php if ($is_admin) { ?>
    <div class="action-bar">
        <a href="match_add.php" class="btn btn-add">+ Schedule New Match</a>
    </div>
<?php } ?>

<h3 class="page-subtitle">Upcoming Matches</h3>
<?php if ($upcoming->num_rows == 0) { ?>
    <p class="text-muted">No upcoming matches scheduled.</p>
<?php } else { ?>
    <table class="data-table">
        <tr>
            <th>Date</th>
            <th>Match</th>
            <th>Venue</th>
            <?php if ($is_admin) { ?><th>Actions</th><?php } ?>
        </tr>
        <?php while ($m = $upcoming->fetch_assoc()) { ?>
        <tr>
            <td><?php echo date("d M Y", strtotime($m['match_date'])); ?></td>
            <td><b><?php echo $m['team1_name']; ?></b> vs <b><?php echo $m['team2_name']; ?></b></td>
            <td><?php echo $m['venue']; ?></td>
            <?php if ($is_admin) { ?>
            <td class="actions">
                <a href="match_result.php?id=<?php echo $m['match_id']; ?>" class="btn btn-primary">Enter Result</a>
                <a href="match_delete.php?id=<?php echo $m['match_id']; ?>" class="btn btn-delete"
                   onclick="return confirm('Delete this match?');">Delete</a>
            </td>
            <?php } ?>
        </tr>
        <?php } ?>
    </table>
<?php } ?>

<h3 class="page-subtitle">Match History</h3>
<?php if ($completed->num_rows == 0) { ?>
    <p class="text-muted">No completed matches yet.</p>
<?php } else { ?>
    <table class="data-table">
        <tr>
            <th>Date</th>
            <th>Match</th>
            <th>Winner</th>
            <th>Result</th>
            <?php if ($is_admin) { ?><th>Actions</th><?php } ?>
        </tr>
        <?php while ($m = $completed->fetch_assoc()) { ?>
        <tr>
            <td><?php echo date("d M Y", strtotime($m['match_date'])); ?></td>
            <td><?php echo $m['team1_name']; ?> vs <?php echo $m['team2_name']; ?></td>
            <td><b><?php echo $m['winner_name']; ?></b></td>
            <td><?php echo $m['winner_name'] . ' won ' . $m['result_margin']; ?></td>
            <?php if ($is_admin) { ?>
            <td class="actions">
                <a href="match_delete.php?id=<?php echo $m['match_id']; ?>" class="btn btn-delete"
                   onclick="return confirm('Delete this match? The points table will be updated automatically.');">Delete</a>
            </td>
            <?php } ?>
        </tr>
        <?php } ?>
    </table>
<?php } ?>

<?php
$conn->close();
include 'includes/footer.php';
?>
