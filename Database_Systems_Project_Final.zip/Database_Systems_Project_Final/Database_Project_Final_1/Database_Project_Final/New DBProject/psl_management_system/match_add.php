<?php

include 'includes/auth_check.php';
include 'includes/connect.php';

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $team1_id   = (int) $_POST['team1_id'];
    $team2_id   = (int) $_POST['team2_id'];
    $match_date = $conn->real_escape_string($_POST['match_date']);
    $venue      = $conn->real_escape_string($_POST['venue']);

    if ($team1_id == $team2_id) {
        $error = "A team cannot play against itself. Please pick two different teams.";
    } else {
        $sql = "INSERT INTO matches (team1_id, team2_id, match_date, venue)
                VALUES ($team1_id, $team2_id, '$match_date', '$venue')";

        if ($conn->query($sql) === TRUE) {
            header("Location: matches.php?msg=Match scheduled successfully!");
            exit();
        } else {
            $error = "Could not schedule match: " . $conn->error;
        }
    }
}

$teams = $conn->query("SELECT team_id, team_name FROM teams ORDER BY team_name");
$teams_data = array();
while ($row = $teams->fetch_assoc()) {
    $teams_data[] = $row;
}
?>
<?php include 'includes/header.php'; ?>

<h2 class="page-title">Schedule New Match</h2>

<?php if ($error != "") { ?>
    <div class="msg msg-error"><?php echo $error; ?></div>
<?php } ?>

<div class="form-box">
    <form action="match_add.php" method="POST">
        <div class="form-row">
            <label for="team1_id">Team 1:</label>
            <select id="team1_id" name="team1_id" required>
                <?php foreach ($teams_data as $t) { ?>
                    <option value="<?php echo $t['team_id']; ?>"><?php echo $t['team_name']; ?></option>
                <?php } ?>
            </select>
        </div>
        <div class="form-row">
            <label for="team2_id">Team 2:</label>
            <select id="team2_id" name="team2_id" required>
                <?php foreach ($teams_data as $t) { ?>
                    <option value="<?php echo $t['team_id']; ?>"><?php echo $t['team_name']; ?></option>
                <?php } ?>
            </select>
        </div>
        <div class="form-row">
            <label for="match_date">Match Date:</label>
            <input type="date" id="match_date" name="match_date" required>
        </div>
        <div class="form-row">
            <label for="venue">Venue:</label>
            <input type="text" id="venue" name="venue" placeholder="e.g. National Stadium, Karachi">
        </div>
        <div class="form-row">
            <button type="submit" class="btn btn-primary">Schedule Match</button>
            <a href="matches.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>

<?php
$conn->close();
include 'includes/footer.php';
?>
