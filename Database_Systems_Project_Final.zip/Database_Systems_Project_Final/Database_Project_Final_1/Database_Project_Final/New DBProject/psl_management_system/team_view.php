<?php

session_start();
include 'includes/connect.php';

$is_admin = isset($_SESSION['admin_id']);

$team_id = (int) $_GET['id'];

$team_sql = "SELECT * FROM teams WHERE team_id = $team_id";
$team_result = $conn->query($team_sql);

if ($team_result->num_rows == 0) {
    echo "Team not found.";
    exit();
}
$team = $team_result->fetch_assoc();

$players_sql = "SELECT * FROM players WHERE team_id = $team_id ORDER BY role, player_name";
$players = $conn->query($players_sql);

$points_sql = "SELECT team_id, matches_played, wins,
                      (matches_played - wins) AS losses,
                      (wins * 2) AS points
               FROM points WHERE team_id = $team_id";
$points = $conn->query($points_sql)->fetch_assoc();

$words = explode(" ", $team['team_name']);
$initials = "";
foreach ($words as $w) {
    $initials .= substr($w, 0, 1);
}
?>
<?php include 'includes/header.php'; ?>

<div class="team-header">
    <span class="team-logo team-logo-large" style="background-color: <?php echo $team['logo_color']; ?>">
        <?php echo $initials; ?>
    </span>
    <div class="team-info">
        <h2><?php echo $team['team_name']; ?></h2>
        <p><b>City:</b> <?php echo $team['city']; ?></p>
        <p><b>Coach:</b> <?php echo $team['coach']; ?></p>
        <p><b>Captain:</b> <?php echo $team['captain']; ?></p>
    </div>
</div>

<div class="card-row">
    <div class="stat-card">
        <h3><?php echo $points['matches_played']; ?></h3>
        <p>Matches Played</p>
    </div>
    <div class="stat-card">
        <h3><?php echo $points['wins']; ?></h3>
        <p>Wins</p>
    </div>
    <div class="stat-card">
        <h3><?php echo $points['losses']; ?></h3>
        <p>Losses</p>
    </div>
    <div class="stat-card">
        <h3><?php echo $points['points']; ?></h3>
        <p>Total Points</p>
    </div>
</div>

<h3 class="page-subtitle">Squad (<?php echo $players->num_rows; ?> players)</h3>

<?php if ($players->num_rows == 0) { ?>
    <p class="text-muted">No players in this squad yet.</p>
<?php } else { ?>
    <table class="data-table">
        <tr>
            <th>Name</th>
            <th>Age</th>
            <th>Role</th>
            <th>Matches</th>
            <th>Runs</th>
            <th>Wickets</th>
        </tr>
        <?php while ($p = $players->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $p['player_name']; ?></td>
            <td><?php echo $p['age']; ?></td>
            <td><span class="role-badge role-<?php echo $p['role']; ?>"><?php echo $p['role']; ?></span></td>
            <td><?php echo $p['matches_played']; ?></td>
            <td><?php echo $p['runs_scored']; ?></td>
            <td><?php echo $p['wickets_taken']; ?></td>
        </tr>
        <?php } ?>
    </table>
<?php } ?>

<p class="mt-20">
    <a href="teams.php" class="btn btn-secondary">&larr; Back to Teams</a>
    <?php if ($is_admin) { ?>
        <a href="team_edit.php?id=<?php echo $team_id; ?>" class="btn btn-edit">Edit Team</a>
        <a href="player_add.php?team_id=<?php echo $team_id; ?>" class="btn btn-add">+ Add Player</a>
    <?php } ?>
</p>

<?php
$conn->close();
include 'includes/footer.php';
?>
