
CREATE DATABASE IF NOT EXISTS psl_management;
USE psl_management;

CREATE TABLE admins (
    admin_id INT NOT NULL AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    PRIMARY KEY (admin_id)
);

CREATE TABLE teams (
    team_id INT NOT NULL AUTO_INCREMENT,
    team_name VARCHAR(50) NOT NULL UNIQUE,
    city VARCHAR(50) NOT NULL,
    coach VARCHAR(50),
    captain VARCHAR(50),
    logo_color VARCHAR(7) NOT NULL DEFAULT '#1e3a8a',
    PRIMARY KEY (team_id)
);
 
 

CREATE TABLE players (
    player_id INT NOT NULL AUTO_INCREMENT,
    player_name VARCHAR(50) NOT NULL,
    age INT NOT NULL CHECK (age >= 16 AND age <= 50),
    role VARCHAR(20) NOT NULL,
    team_id INT NOT NULL,
    matches_played INT NOT NULL DEFAULT 0,
    runs_scored INT NOT NULL DEFAULT 0,
    wickets_taken INT NOT NULL DEFAULT 0,
    PRIMARY KEY (player_id),
    FOREIGN KEY (team_id) REFERENCES teams(team_id) ON DELETE CASCADE
);
 
 

CREATE TABLE matches (
    match_id INT NOT NULL AUTO_INCREMENT,
    team1_id INT NOT NULL,
    team2_id INT NOT NULL,
    match_date DATE NOT NULL,
    venue VARCHAR(100),
    winner_id INT DEFAULT NULL,
    result_margin VARCHAR(255),
    PRIMARY KEY (match_id),
    FOREIGN KEY (team1_id) REFERENCES teams(team_id) ON DELETE CASCADE,
    FOREIGN KEY (team2_id) REFERENCES teams(team_id) ON DELETE CASCADE,
    FOREIGN KEY (winner_id) REFERENCES teams(team_id) ON DELETE CASCADE
);
 
 

CREATE TABLE points (
    team_id INT NOT NULL,
    matches_played INT NOT NULL DEFAULT 0,
    wins INT NOT NULL DEFAULT 0,
    PRIMARY KEY (team_id),
    FOREIGN KEY (team_id) REFERENCES teams(team_id) ON DELETE CASCADE
);
 
 

INSERT INTO admins (username, password) VALUES
('admin', '$2y$10$bRKxRpDtMNJWIkKZBGAYmuXwq1Vhz2vfSjmTo8dg4sPkW9aeBF8Km');
 
 
INSERT INTO teams (team_name, city, coach, captain, logo_color) VALUES
('Karachi Kings', 'Karachi', 'Ravi Bopara', 'Shan Masood', '#005DA8'),
('Lahore Qalandars', 'Lahore', 'Aaqib Javed', 'Shaheen Afridi', '#1B5E20'),
('Islamabad United', 'Islamabad', 'Azhar Mahmood', 'Shadab Khan', '#E65100'),
('Multan Sultans', 'Multan', 'Andy Flower', 'Mohammad Rizwan', '#4A148C'),
('Peshawar Zalmi', 'Peshawar', 'Mohammad Akram', 'Babar Azam', '#FFD600'),
('Quetta Gladiators', 'Quetta', 'Shane Bond', 'Sarfaraz Ahmed', '#7B1FA2'),
('Pindiz', 'Rawalpindi', 'Misbah-ul-Haq', 'Mohammad Nawaz', '#D32F2F'),
('Kingsmen Hyderabad', 'Hyderabad', 'Waqar Younis', 'Imad Wasim', '#00838F');
 
 
INSERT INTO players (player_name, age, role, team_id, matches_played, runs_scored, wickets_taken) VALUES
('Shan Masood', 34, 'Batsman', 1, 8, 312, 0),
('Mir Hamza', 32, 'Bowler', 1, 8, 15, 14),
('Tim Seifert', 29, 'Wicketkeeper', 1, 7, 245, 0),
('Daniel Sams', 31, 'All-rounder', 1, 8, 98, 9),
('Hasan Ali', 29, 'Bowler', 1, 7, 28, 11),
 
('Shaheen Afridi', 23, 'Bowler', 2, 9, 45, 17),
('Fakhar Zaman', 33, 'Batsman', 2, 9, 421, 0),
('Rashid Khan', 25, 'All-rounder', 2, 8, 67, 14),
('David Wiese', 38, 'All-rounder', 2, 7, 156, 6),
('Mohammad Hafeez', 43, 'All-rounder', 2, 6, 89, 3),
 
('Shadab Khan', 25, 'All-rounder', 3, 8, 134, 12),
('Colin Munro', 36, 'Batsman', 3, 8, 298, 0),
('Habeeb Shah', 20, 'Bowler', 3, 7, 22, 13),
('Faheem Ashraf', 29, 'All-rounder', 3, 8, 145, 8),
('Azam Khan', 25, 'Wicketkeeper', 3, 7, 187, 0),
 
('Mohammad Rizwan', 31, 'Wicketkeeper', 4, 9, 387, 0),
('Usama Mir', 28, 'Bowler', 4, 8, 18, 15),
('Ihsanullah', 21, 'Bowler', 4, 7, 12, 12),
('Iftikhar Ahmed', 33, 'Batsman', 4, 9, 234, 2),
('Khushdil Shah', 28, 'All-rounder', 4, 8, 178, 4),
 
('Babar Azam', 29, 'Batsman', 5, 9, 489, 0),
('Saim Ayub', 21, 'Batsman', 5, 8, 256, 1),
('Wahab Riaz', 38, 'Bowler', 5, 7, 14, 10),
('Mohammad Haris', 22, 'Wicketkeeper', 5, 8, 178, 0),
('Sufyan Muqeem', 22, 'Bowler', 5, 6, 8, 9),
 
('Sarfaraz Ahmed', 36, 'Wicketkeeper', 6, 8, 215, 0),
('Mohammad Hasnain', 23, 'Bowler', 6, 7, 11, 11),
('Naseem Shah', 20, 'Bowler', 6, 7, 19, 13),
('Akeal Hosein', 30, 'All-rounder', 6, 7, 78, 9),
('Khurram Shahzad', 24, 'Bowler', 6, 6, 9, 8),
 
('Mohammad Nawaz', 29, 'All-rounder', 7, 8, 112, 10),
('Haider Ali', 23, 'Batsman', 7, 7, 198, 0),
('Mohammad Wasim Jr', 23, 'All-rounder', 7, 8, 89, 11),
('Zaman Khan', 23, 'Bowler', 7, 7, 16, 12),
('Rohail Nazir', 22, 'Wicketkeeper', 7, 6, 143, 0),
 
('Imad Wasim', 35, 'All-rounder', 8, 9, 167, 7),
('Sharjeel Khan', 35, 'Batsman', 8, 8, 278, 0),
('Mohammad Amir', 32, 'Bowler', 8, 8, 21, 14),
('Asif Ali', 32, 'Batsman', 8, 7, 156, 0),
('Kamran Akmal', 42, 'Wicketkeeper', 8, 6, 132, 0);
 
 
INSERT INTO points (team_id) VALUES (1), (2), (3), (4), (5), (6), (7), (8);
 
 
INSERT INTO matches (team1_id, team2_id, match_date, venue, winner_id, result_margin) VALUES
(1, 2, '2024-02-17', 'National Stadium, Karachi', 2, 'by 6 wickets'),
(3, 4, '2024-02-18', 'Pindi Stadium, Rawalpindi', 3, 'by 4 runs'),
(5, 6, '2024-02-19', 'Gaddafi Stadium, Lahore', 5, 'by 8 wickets'),
(2, 3, '2024-02-22', 'Gaddafi Stadium, Lahore', 3, 'by 12 runs'),
(4, 5, '2024-02-23', 'Multan Cricket Stadium', 4, 'by 5 wickets'),
(1, 6, '2024-02-24', 'National Stadium, Karachi', 6, 'by 3 wickets'),
(2, 4, '2024-02-27', 'Gaddafi Stadium, Lahore', NULL, NULL),
(3, 5, '2024-02-28', 'Pindi Stadium, Rawalpindi', NULL, NULL),
(7, 1, '2024-02-20', 'Pindi Cricket Stadium, Rawalpindi', 7, 'by 5 runs'),
(8, 2, '2024-02-21', 'Niaz Stadium, Hyderabad', 2, 'by 7 wickets'),
(7, 8, '2024-02-25', 'Pindi Cricket Stadium, Rawalpindi', 8, 'by 3 wickets'),
(6, 7, '2024-02-26', 'Bugti Stadium, Quetta', 7, 'by 22 runs'),
(8, 5, '2024-03-01', 'Niaz Stadium, Hyderabad', NULL, NULL);
 
 

UPDATE points SET matches_played = 3, wins = 0 WHERE team_id = 1;
UPDATE points SET matches_played = 3, wins = 2 WHERE team_id = 2;
UPDATE points SET matches_played = 2, wins = 2 WHERE team_id = 3;
UPDATE points SET matches_played = 2, wins = 1 WHERE team_id = 4;
UPDATE points SET matches_played = 2, wins = 1 WHERE team_id = 5;
UPDATE points SET matches_played = 3, wins = 1 WHERE team_id = 6;
UPDATE points SET matches_played = 3, wins = 2 WHERE team_id = 7;
UPDATE points SET matches_played = 2, wins = 1 WHERE team_id = 8;
