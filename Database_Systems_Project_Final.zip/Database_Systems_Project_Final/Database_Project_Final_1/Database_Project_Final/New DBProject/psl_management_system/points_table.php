<?php


include 'includes/connect.php';

$sql = "SELECT t.team_id, t.team_name, t.logo_color,
               p.matches_played, p.wins,
               (p.matches_played - p.wins) AS losses,
               (p.wins * 2) AS points
        FROM points p
        INNER JOIN teams t ON p.team_id = t.team_id
        ORDER BY (p.wins * 2) DESC, p.wins DESC, t.team_name ASC";

$result = $conn->query($sql);
?>
<?php include 'includes/header.php'; ?>

<h2 class="page-title">Points Table</h2>
<p class="text-muted">Teams ranked by total points. Each win earns 2 points, each loss earns 0 points.</p>

<table class="data-table mt-20">
    <tr>
        <th>Rank</th>
        <th>Team</th>
        <th>Played</th>
        <th>Won</th>
        <th>Lost</th>
        <th>Points</th>
    </tr>
    <?php
    $rank = 1;
    while ($row = $result->fetch_assoc()) {
        $words = explode(" ", $row['team_name']);
        $initials = "";
        foreach ($words as $w) {
            $initials .= substr($w, 0, 1);
        }
    ?>
    <tr>
        <td><b><?php echo $rank++; ?></b></td>
        <td>
            <span class="team-logo" style="background-color: <?php echo $row['logo_color']; ?>">
                <?php echo $initials; ?>
            </span>
            <a href="team_view.php?id=<?php echo $row['team_id']; ?>"><?php echo $row['team_name']; ?></a>
        </td>
        <td><?php echo $row['matches_played']; ?></td>
        <td><?php echo $row['wins']; ?></td>
        <td><?php echo $row['losses']; ?></td>
        <td><b style="font-size: 16px; color: #1b5e20;"><?php echo $row['points']; ?></b></td>
    </tr>
    <?php } ?>
</table>

<?php
$conn->close();
include 'includes/footer.php';
?>
