<?php


include 'includes/auth_check.php';
include 'includes/connect.php';

$error = "";
$match_id = (int) $_GET['id'];

$result = $conn->query("SELECT m.*, t1.team_name AS team1_name, t2.team_name AS team2_name
                        FROM matches m
                        INNER JOIN teams t1 ON m.team1_id = t1.team_id
                        INNER JOIN teams t2 ON m.team2_id = t2.team_id
                        WHERE m.match_id = $match_id");
if ($result->num_rows == 0) {
    echo "Match not found.";
    exit();
}
$match = $result->fetch_assoc();

if ($match['winner_id'] != NULL) {
    echo "This match's result has already been recorded.";
    echo '<br><a href="matches.php">Back to Matches</a>';
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $winner_id   = (int) $_POST['winner_id'];
    $result_margin = $conn->real_escape_string($_POST['result_margin']);

    if ($winner_id != $match['team1_id'] && $winner_id != $match['team2_id']) {
        $error = "The winner must be one of the two teams in this match.";
    } else {

        $update_match = "UPDATE matches
                         SET winner_id = $winner_id,
                             result_margin = '$result_margin'
                         WHERE match_id = $match_id";
        $conn->query($update_match);

        $loser_id = ($winner_id == $match['team1_id']) ? $match['team2_id'] : $match['team1_id'];

        $conn->query("UPDATE points
                      SET matches_played = matches_played + 1,
                          wins = wins + 1
                      WHERE team_id = $winner_id");

        $conn->query("UPDATE points
                      SET matches_played = matches_played + 1
                      WHERE team_id = $loser_id");

        header("Location: matches.php?msg=Match result recorded and points table updated!");
        exit();
    }
}
?>
<?php include 'includes/header.php'; ?>

<h2 class="page-title">Enter Match Result</h2>

<?php if ($error != "") { ?>
    <div class="msg msg-error"><?php echo $error; ?></div>
<?php } ?>

<div class="msg msg-info">
    <b>Match:</b> <?php echo $match['team1_name']; ?> vs <?php echo $match['team2_name']; ?><br>
    <b>Date:</b> <?php echo date("d M Y", strtotime($match['match_date'])); ?><br>
    <b>Venue:</b> <?php echo $match['venue']; ?>
</div>

<div class="form-box">
    <form action="match_result.php?id=<?php echo $match_id; ?>" method="POST">
        <div class="form-row">
            <label for="winner_id">Winner:</label>
            <select id="winner_id" name="winner_id" required>
                <option value="<?php echo $match['team1_id']; ?>"><?php echo $match['team1_name']; ?></option>
                <option value="<?php echo $match['team2_id']; ?>"><?php echo $match['team2_name']; ?></option>
            </select>
        </div>
        <div class="form-row">
            <label for="result_margin">Result Margin:</label>
            <input type="text" id="result_margin" name="result_margin" placeholder="e.g. by 6 wickets" required>
        </div>
        <div class="form-row">
            <button type="submit" class="btn btn-primary">Save Result</button>
            <a href="matches.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>

<?php
$conn->close();
include 'includes/footer.php';
?>
