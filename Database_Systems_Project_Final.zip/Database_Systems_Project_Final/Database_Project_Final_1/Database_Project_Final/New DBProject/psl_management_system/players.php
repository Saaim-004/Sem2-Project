<?php


session_start();
include 'includes/connect.php';

$is_admin = isset($_SESSION['admin_id']);

$search_name = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : "";
$filter_team = isset($_GET['team'])   ? (int) $_GET['team']                         : 0;
$filter_role = isset($_GET['role'])   ? $conn->real_escape_string($_GET['role'])   : "";

$sql = "SELECT p.*, t.team_name, t.logo_color
        FROM players p
        INNER JOIN teams t ON p.team_id = t.team_id
        WHERE 1 = 1";

if ($search_name != "") {
    $sql .= " AND p.player_name LIKE '%$search_name%'";
}
if ($filter_team > 0) {
    $sql .= " AND p.team_id = $filter_team";
}
if ($filter_role != "") {
    $sql .= " AND p.role = '$filter_role'";
}

$sql .= " ORDER BY p.player_name ASC";

$result = $conn->query($sql);

$teams_for_dropdown = $conn->query("SELECT team_id, team_name FROM teams ORDER BY team_name");
?>
<?php include 'includes/header.php'; ?>

<h2 class="page-title">Players</h2>

<?php if (isset($_GET['msg'])) { ?>
    <div class="msg msg-success"><?php echo $conn->real_escape_string($_GET['msg']); ?></div>
<?php } ?>

<!-- Search and filter bar -->
<div class="search-bar">
    <form action="players.php" method="GET">
        <input type="text" name="search" placeholder="Search by player name..." value="<?php echo $search_name; ?>">

        <select name="team">
            <option value="0">All Teams</option>
            <?php while ($t = $teams_for_dropdown->fetch_assoc()) { ?>
                <option value="<?php echo $t['team_id']; ?>"
                    <?php if ($filter_team == $t['team_id']) echo "selected"; ?>>
                    <?php echo $t['team_name']; ?>
                </option>
            <?php } ?>
        </select>

        <select name="role">
            <option value="">All Roles</option>
            <option value="Batsman"      <?php if ($filter_role == "Batsman")      echo "selected"; ?>>Batsman</option>
            <option value="Bowler"       <?php if ($filter_role == "Bowler")       echo "selected"; ?>>Bowler</option>
            <option value="All-rounder"  <?php if ($filter_role == "All-rounder")  echo "selected"; ?>>All-rounder</option>
            <option value="Wicketkeeper" <?php if ($filter_role == "Wicketkeeper") echo "selected"; ?>>Wicketkeeper</option>
        </select>

        <button type="submit" class="btn btn-primary">Search</button>
        <a href="players.php" class="btn btn-secondary">Reset</a>
    </form>
</div>

<?php if ($is_admin) { ?>
    <div class="action-bar">
        <a href="player_add.php" class="btn btn-add">+ Add New Player</a>
    </div>
<?php } ?>

<p><b><?php echo $result->num_rows; ?></b> player(s) found.</p>

<table class="data-table">
    <tr>
        <th>Name</th>
        <th>Team</th>
        <th>Age</th>
        <th>Role</th>
        <th>Matches</th>
        <th>Runs</th>
        <th>Wickets</th>
        <?php if ($is_admin) { ?><th>Actions</th><?php } ?>
    </tr>
    <?php if ($result->num_rows == 0) { ?>
        <tr><td colspan="<?php echo $is_admin ? 8 : 7; ?>" class="text-center text-muted">No players match your search.</td></tr>
    <?php } else {
        while ($p = $result->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $p['player_name']; ?></td>
            <td>
                <span class="team-logo" style="background-color: <?php echo $p['logo_color']; ?>; width: 22px; height: 22px; line-height: 22px; font-size: 10px;">
                    <?php
                    $words = explode(" ", $p['team_name']);
                    $initials = "";
                    foreach ($words as $w) { $initials .= substr($w, 0, 1); }
                    echo $initials;
                    ?>
                </span>
                <?php echo $p['team_name']; ?>
            </td>
            <td><?php echo $p['age']; ?></td>
            <td><span class="role-badge role-<?php echo $p['role']; ?>"><?php echo $p['role']; ?></span></td>
            <td><?php echo $p['matches_played']; ?></td>
            <td><?php echo $p['runs_scored']; ?></td>
            <td><?php echo $p['wickets_taken']; ?></td>
            <?php if ($is_admin) { ?>
            <td class="actions">
                <a href="player_edit.php?id=<?php echo $p['player_id']; ?>" class="btn btn-edit">Edit</a>
                <a href="player_delete.php?id=<?php echo $p['player_id']; ?>" class="btn btn-delete"
                   onclick="return confirm('Are you sure you want to delete this player?');">Delete</a>
            </td>
            <?php } ?>
        </tr>
    <?php } } ?>
</table>

<?php
$conn->close();
include 'includes/footer.php';
?>
