<?php


include 'includes/auth_check.php';
include 'includes/connect.php';

$match_id = (int) $_GET['id'];

$result = $conn->query("SELECT * FROM matches WHERE match_id = $match_id");
if ($result->num_rows == 0) {
    echo "Match not found.";
    exit();
}
$match = $result->fetch_assoc();

if ($match['winner_id'] != NULL) {

    $winner_id = $match['winner_id'];
    $loser_id  = ($winner_id == $match['team1_id']) ? $match['team2_id'] : $match['team1_id'];

    $conn->query("UPDATE points
                  SET matches_played = matches_played - 1,
                      wins = wins - 1
                  WHERE team_id = $winner_id");

    $conn->query("UPDATE points
                  SET matches_played = matches_played - 1
                  WHERE team_id = $loser_id");
}

if ($conn->query("DELETE FROM matches WHERE match_id = $match_id") === TRUE) {
    header("Location: matches.php?msg=Match deleted successfully!");
    exit();
} else {
    echo "Could not delete match: " . $conn->error;
    echo '<br><a href="matches.php">Back to Matches</a>';
}

$conn->close();
?>
