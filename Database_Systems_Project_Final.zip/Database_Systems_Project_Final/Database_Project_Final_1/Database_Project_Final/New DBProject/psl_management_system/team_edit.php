<?php

include 'includes/auth_check.php';
include 'includes/connect.php';

$error = "";
$team_id = (int) $_GET['id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $team_name  = $conn->real_escape_string($_POST['team_name']);
    $city       = $conn->real_escape_string($_POST['city']);
    $coach      = $conn->real_escape_string($_POST['coach']);
    $captain    = $conn->real_escape_string($_POST['captain']);
    $logo_color = $conn->real_escape_string($_POST['logo_color']);

    $sql = "UPDATE teams
            SET team_name = '$team_name',
                city = '$city',
                coach = '$coach',
                captain = '$captain',
                logo_color = '$logo_color'
            WHERE team_id = $team_id";

    if ($conn->query($sql) === TRUE) {
        header("Location: teams.php?msg=Team updated successfully!");
        exit();
    } else {
        $error = "Could not update team: " . $conn->error;
    }
}

$result = $conn->query("SELECT * FROM teams WHERE team_id = $team_id");
if ($result->num_rows == 0) {
    echo "Team not found.";
    exit();
}
$team = $result->fetch_assoc();
?>
<?php include 'includes/header.php'; ?>

<h2 class="page-title">Edit Team</h2>

<?php if ($error != "") { ?>
    <div class="msg msg-error"><?php echo $error; ?></div>
<?php } ?>

<div class="form-box">
    <form action="team_edit.php?id=<?php echo $team_id; ?>" method="POST">
        <div class="form-row">
            <label for="team_name">Team Name:</label>
            <input type="text" id="team_name" name="team_name" value="<?php echo $team['team_name']; ?>" required>
        </div>
        <div class="form-row">
            <label for="city">City:</label>
            <input type="text" id="city" name="city" value="<?php echo $team['city']; ?>" required>
        </div>
        <div class="form-row">
            <label for="coach">Coach:</label>
            <input type="text" id="coach" name="coach" value="<?php echo $team['coach']; ?>">
        </div>
        <div class="form-row">
            <label for="captain">Captain:</label>
            <input type="text" id="captain" name="captain" value="<?php echo $team['captain']; ?>">
        </div>
        <div class="form-row">
            <label for="logo_color">Team Color:</label>
            <input type="color" id="logo_color" name="logo_color" value="<?php echo $team['logo_color']; ?>">
        </div>
        <div class="form-row">
            <button type="submit" class="btn btn-primary">Save Changes</button>
            <a href="teams.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>

<?php
$conn->close();
include 'includes/footer.php';
?>
