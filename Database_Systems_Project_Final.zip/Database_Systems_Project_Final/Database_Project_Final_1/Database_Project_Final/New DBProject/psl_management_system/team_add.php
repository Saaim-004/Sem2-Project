<?php


include 'includes/auth_check.php';
include 'includes/connect.php';

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $team_name  = $conn->real_escape_string($_POST['team_name']);
    $city       = $conn->real_escape_string($_POST['city']);
    $coach      = $conn->real_escape_string($_POST['coach']);
    $captain    = $conn->real_escape_string($_POST['captain']);
    $logo_color = $conn->real_escape_string($_POST['logo_color']);

    $sql = "INSERT INTO teams (team_name, city, coach, captain, logo_color)
            VALUES ('$team_name', '$city', '$coach', '$captain', '$logo_color')";

    if ($conn->query($sql) === TRUE) {
        $new_team_id = $conn->insert_id;
        $conn->query("INSERT INTO points (team_id) VALUES ($new_team_id)");

        header("Location: teams.php?msg=Team added successfully!");
        exit();
    } else {
        $error = "Could not add team: " . $conn->error;
    }
}
?>
<?php include 'includes/header.php'; ?>

<h2 class="page-title">Add New Team</h2>

<?php if ($error != "") { ?>
    <div class="msg msg-error"><?php echo $error; ?></div>
<?php } ?>

<div class="form-box">
    <form action="team_add.php" method="POST">
        <div class="form-row">
            <label for="team_name">Team Name:</label>
            <input type="text" id="team_name" name="team_name" required>
        </div>
        <div class="form-row">
            <label for="city">City:</label>
            <input type="text" id="city" name="city" required>
        </div>
        <div class="form-row">
            <label for="coach">Coach:</label>
            <input type="text" id="coach" name="coach">
        </div>
        <div class="form-row">
            <label for="captain">Captain:</label>
            <input type="text" id="captain" name="captain">
        </div>
        <div class="form-row">
            <label for="logo_color">Team Color (used for the team logo):</label>
            <input type="color" id="logo_color" name="logo_color" value="#1e3a8a">
        </div>
        <div class="form-row">
            <button type="submit" class="btn btn-primary">Add Team</button>
            <a href="teams.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>

<?php
$conn->close();
include 'includes/footer.php';
?>
