<?php


session_start();
include 'includes/connect.php';

$is_admin = isset($_SESSION['admin_id']);

$sql = "SELECT t.*, (SELECT COUNT(*) FROM players p WHERE p.team_id = t.team_id) AS squad_size
        FROM teams t
        ORDER BY t.team_name ASC";
$result = $conn->query($sql);
?>
<?php include 'includes/header.php'; ?>

<h2 class="page-title">PSL Teams</h2>

<?php if (isset($_GET['msg'])) { ?>
    <div class="msg msg-success"><?php echo $conn->real_escape_string($_GET['msg']); ?></div>
<?php } ?>

<?php if ($is_admin) { ?>
    <div class="action-bar">
        <a href="team_add.php" class="btn btn-add">+ Add New Team</a>
    </div>
<?php } ?>

<table class="data-table">
    <tr>
        <th>Logo</th>
        <th>Team Name</th>
        <th>City</th>
        <th>Coach</th>
        <th>Captain</th>
        <th>Squad Size</th>
        <th>Actions</th>
    </tr>
    <?php while ($team = $result->fetch_assoc()) {
        $words = explode(" ", $team['team_name']);
        $initials = "";
        foreach ($words as $w) {
            $initials .= substr($w, 0, 1);
        }
    ?>
    <tr>
        <td>
            <span class="team-logo" style="background-color: <?php echo $team['logo_color']; ?>">
                <?php echo $initials; ?>
            </span>
        </td>
        <td><?php echo $team['team_name']; ?></td>
        <td><?php echo $team['city']; ?></td>
        <td><?php echo $team['coach']; ?></td>
        <td><?php echo $team['captain']; ?></td>
        <td><?php echo $team['squad_size']; ?> players</td>
        <td class="actions">
            <a href="team_view.php?id=<?php echo $team['team_id']; ?>" class="btn btn-secondary">View</a>
            <?php if ($is_admin) { ?>
                <a href="team_edit.php?id=<?php echo $team['team_id']; ?>" class="btn btn-edit">Edit</a>
                <a href="team_delete.php?id=<?php echo $team['team_id']; ?>" class="btn btn-delete"
                   onclick="return confirm('Are you sure you want to delete this team? All its players will also be removed.');">Delete</a>
            <?php } ?>
        </td>
    </tr>
    <?php } ?>
</table>

<?php
$conn->close();
include 'includes/footer.php';
?>
