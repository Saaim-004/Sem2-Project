<?php


session_start();
include 'includes/connect.php';

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];

    $sql = "SELECT * FROM admins WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();

        if (password_verify($password, $row['password'])) {
            $_SESSION['admin_id'] = $row['admin_id'];
            $_SESSION['username'] = $row['username'];
            header("Location: index.php");
            exit();
        } else {
            $error = "Incorrect password. Please try again.";
        }
    } else {
        $error = "No admin found with that username.";
    }
}

$conn->close();
?>
<?php include 'includes/header.php'; ?>

<div class="login-wrapper">
    <h2 class="page-title text-center">Admin Login</h2>

    <?php if ($error != "") { ?>
        <div class="msg msg-error"><?php echo $error; ?></div>
    <?php } ?>

    <div class="form-box">
        <form action="login.php" method="POST">
            <div class="form-row">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-row">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-row text-center">
                <button type="submit" class="btn btn-primary">Login</button>
            </div>
        </form>
        <p class="text-muted text-center" style="margin-top: 12px; font-size: 13px;">
            Default account &mdash; Username: <b>admin</b> &middot; Password: <b>admin123</b>
        </p>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
