<?php
// =====================================================
// Database Connection File
// This file connects PHP to the MySQL database.
// It is included at the top of every page that needs
// to read or write data.
// =====================================================

// 1. Database Configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "psl_management";

// 2. Create Connection
$conn = new mysqli($servername, $username, $password, $dbname);

// 3. Check Connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
