<?php
// =====================================================
// Common Page Header
// Contains the top bar and navigation links shown on
// every page. The "Admin Login" or "Logout" link
// changes depending on whether an admin is logged in.
// =====================================================

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PSL Team Management System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="topbar">
    <div class="topbar-inner">
        <h1 class="site-title">PSL Team Management System</h1>
        <nav class="main-nav">
            <a href="index.php">Home</a>
            <a href="teams.php">Teams</a>
            <a href="players.php">Players</a>
            <a href="matches.php">Matches</a>
            <a href="points_table.php">Points Table</a>
            <a href="analytics.php">Analytics</a>
            <?php if (isset($_SESSION['admin_id'])) { ?>
                <a href="logout.php" class="nav-logout">Logout (<?php echo $_SESSION['username']; ?>)</a>
            <?php } else { ?>
                <a href="login.php" class="nav-login">Admin Login</a>
            <?php } ?>
        </nav>
    </div>
</div>

<div class="page-container">
