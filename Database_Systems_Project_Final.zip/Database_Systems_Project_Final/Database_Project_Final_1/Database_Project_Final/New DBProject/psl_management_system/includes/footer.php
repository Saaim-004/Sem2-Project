</div> <!-- end of .page-container -->

<div class="page-footer">
    <p>PSL Team Management System &middot; Database Systems Project &middot; BSCS 2nd Semester</p>
</div>

</body>
</html>
