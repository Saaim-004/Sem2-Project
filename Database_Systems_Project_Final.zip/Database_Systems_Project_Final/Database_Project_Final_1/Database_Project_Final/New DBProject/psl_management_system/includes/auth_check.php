<?php
// =====================================================
// Admin Authentication Check
// Include this file at the top of any page that should
// only be accessible to logged-in administrators.
// If no admin is logged in, the user is redirected to
// the login page.
// =====================================================

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}
?>
