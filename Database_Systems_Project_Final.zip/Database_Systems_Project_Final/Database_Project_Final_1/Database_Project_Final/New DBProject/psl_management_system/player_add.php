<?php


include 'includes/auth_check.php';
include 'includes/connect.php';

$error = "";
$preselected_team = isset($_GET['team_id']) ? (int) $_GET['team_id'] : 0;

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $player_name    = $conn->real_escape_string($_POST['player_name']);
    $age            = (int) $_POST['age'];
    $role           = $conn->real_escape_string($_POST['role']);
    $team_id        = (int) $_POST['team_id'];
    $matches_played = (int) $_POST['matches_played'];
    $runs_scored    = (int) $_POST['runs_scored'];
    $wickets_taken  = (int) $_POST['wickets_taken'];

    if ($age < 16 || $age > 50) {
        $error = "Age must be between 16 and 50.";
    } else {
        $sql = "INSERT INTO players (player_name, age, role, team_id, matches_played, runs_scored, wickets_taken)
                VALUES ('$player_name', $age, '$role', $team_id, $matches_played, $runs_scored, $wickets_taken)";

        if ($conn->query($sql) === TRUE) {
            header("Location: players.php?msg=Player added successfully!");
            exit();
        } else {
            $error = "Could not add player: " . $conn->error;
        }
    }
}

$teams = $conn->query("SELECT team_id, team_name FROM teams ORDER BY team_name");
?>
<?php include 'includes/header.php'; ?>

<h2 class="page-title">Add New Player</h2>

<?php if ($error != "") { ?>
    <div class="msg msg-error"><?php echo $error; ?></div>
<?php } ?>

<div class="form-box">
    <form action="player_add.php" method="POST">
        <div class="form-row">
            <label for="player_name">Player Name:</label>
            <input type="text" id="player_name" name="player_name" required>
        </div>
        <div class="form-row">
            <label for="age">Age:</label>
            <input type="number" id="age" name="age" min="16" max="50" required>
        </div>
        <div class="form-row">
            <label for="role">Role:</label>
            <select id="role" name="role" required>
                <option value="Batsman">Batsman</option>
                <option value="Bowler">Bowler</option>
                <option value="All-rounder">All-rounder</option>
                <option value="Wicketkeeper">Wicketkeeper</option>
            </select>
        </div>
        <div class="form-row">
            <label for="team_id">Team:</label>
            <select id="team_id" name="team_id" required>
                <?php while ($t = $teams->fetch_assoc()) { ?>
                    <option value="<?php echo $t['team_id']; ?>"
                        <?php if ($preselected_team == $t['team_id']) echo "selected"; ?>>
                        <?php echo $t['team_name']; ?>
                    </option>
                <?php } ?>
            </select>
        </div>
        <div class="form-row">
            <label for="matches_played">Matches Played:</label>
            <input type="number" id="matches_played" name="matches_played" min="0" value="0">
        </div>
        <div class="form-row">
            <label for="runs_scored">Runs Scored:</label>
            <input type="number" id="runs_scored" name="runs_scored" min="0" value="0">
        </div>
        <div class="form-row">
            <label for="wickets_taken">Wickets Taken:</label>
            <input type="number" id="wickets_taken" name="wickets_taken" min="0" value="0">
        </div>
        <div class="form-row">
            <button type="submit" class="btn btn-primary">Add Player</button>
            <a href="players.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>

<?php
$conn->close();
include 'includes/footer.php';
?>
