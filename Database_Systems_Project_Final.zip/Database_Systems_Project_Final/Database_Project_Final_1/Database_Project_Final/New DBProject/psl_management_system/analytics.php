<?php


include 'includes/connect.php';

$role_filter = isset($_GET['role']) ? $conn->real_escape_string($_GET['role']) : "";
$role_where  = ($role_filter != "") ? "AND p.role = '$role_filter'" : "";

$top_runs = $conn->query(
    "SELECT p.player_name, p.role, p.runs_scored, p.matches_played, t.team_name, t.logo_color
     FROM players p
     INNER JOIN teams t ON p.team_id = t.team_id
     WHERE p.runs_scored > 0 $role_where
     ORDER BY p.runs_scored DESC
     LIMIT 5"
);

$top_wickets = $conn->query(
    "SELECT p.player_name, p.role, p.wickets_taken, p.matches_played, t.team_name, t.logo_color
     FROM players p
     INNER JOIN teams t ON p.team_id = t.team_id
     WHERE p.wickets_taken > 0 $role_where
     ORDER BY p.wickets_taken DESC
     LIMIT 5"
);

$best_avg = $conn->query(
    "SELECT p.player_name, p.role, p.runs_scored, p.matches_played, t.team_name, t.logo_color,
            ROUND(p.runs_scored / p.matches_played, 2) AS avg_runs
     FROM players p
     INNER JOIN teams t ON p.team_id = t.team_id
     WHERE p.matches_played >= 3 $role_where
     ORDER BY avg_runs DESC
     LIMIT 5"
);

$team_counts = $conn->query(
    "SELECT t.team_name, t.logo_color, COUNT(p.player_id) AS total_players
     FROM teams t
     LEFT JOIN players p ON t.team_id = p.team_id
     GROUP BY t.team_id
     ORDER BY total_players DESC"
);
?>
<?php include 'includes/header.php'; ?>

<h2 class="page-title">Tournament Analytics</h2>
<p class="text-muted">Performance statistics across all PSL teams. Use the filter to narrow the player lists by role.</p>

<!-- Role filter -->
<div class="search-bar">
    <form action="analytics.php" method="GET">
        <label><b>Filter by Role:</b></label>
        <select name="role">
            <option value="">All Roles</option>
            <option value="Batsman"      <?php if ($role_filter == "Batsman")      echo "selected"; ?>>Batsman</option>
            <option value="Bowler"       <?php if ($role_filter == "Bowler")       echo "selected"; ?>>Bowler</option>
            <option value="All-rounder"  <?php if ($role_filter == "All-rounder")  echo "selected"; ?>>All-rounder</option>
            <option value="Wicketkeeper" <?php if ($role_filter == "Wicketkeeper") echo "selected"; ?>>Wicketkeeper</option>
        </select>
        <button type="submit" class="btn btn-primary">Apply Filter</button>
        <a href="analytics.php" class="btn btn-secondary">Reset</a>
    </form>
</div>

<!-- Top run scorers -->
<h3 class="page-subtitle">Top 5 Run Scorers</h3>
<?php if ($top_runs->num_rows == 0) { ?>
    <p class="text-muted">No matching players found.</p>
<?php } else { ?>
    <table class="data-table">
        <tr>
            <th>#</th>
            <th>Player</th>
            <th>Team</th>
            <th>Role</th>
            <th>Runs</th>
            <th>Matches</th>
        </tr>
        <?php $rank = 1; while ($row = $top_runs->fetch_assoc()) { ?>
        <tr>
            <td><b><?php echo $rank++; ?></b></td>
            <td><?php echo $row['player_name']; ?></td>
            <td><?php echo $row['team_name']; ?></td>
            <td><span class="role-badge role-<?php echo $row['role']; ?>"><?php echo $row['role']; ?></span></td>
            <td><b><?php echo $row['runs_scored']; ?></b></td>
            <td><?php echo $row['matches_played']; ?></td>
        </tr>
        <?php } ?>
    </table>
<?php } ?>

<!-- Top wicket takers -->
<h3 class="page-subtitle">Top 5 Wicket Takers</h3>
<?php if ($top_wickets->num_rows == 0) { ?>
    <p class="text-muted">No matching players found.</p>
<?php } else { ?>
    <table class="data-table">
        <tr>
            <th>#</th>
            <th>Player</th>
            <th>Team</th>
            <th>Role</th>
            <th>Wickets</th>
            <th>Matches</th>
        </tr>
        <?php $rank = 1; while ($row = $top_wickets->fetch_assoc()) { ?>
        <tr>
            <td><b><?php echo $rank++; ?></b></td>
            <td><?php echo $row['player_name']; ?></td>
            <td><?php echo $row['team_name']; ?></td>
            <td><span class="role-badge role-<?php echo $row['role']; ?>"><?php echo $row['role']; ?></span></td>
            <td><b><?php echo $row['wickets_taken']; ?></b></td>
            <td><?php echo $row['matches_played']; ?></td>
        </tr>
        <?php } ?>
    </table>
<?php } ?>

<!-- Best batting average -->
<h3 class="page-subtitle">Best Batting Average (Runs per Match, min. 3 matches)</h3>
<?php if ($best_avg->num_rows == 0) { ?>
    <p class="text-muted">No matching players found.</p>
<?php } else { ?>
    <table class="data-table">
        <tr>
            <th>#</th>
            <th>Player</th>
            <th>Team</th>
            <th>Role</th>
            <th>Runs</th>
            <th>Matches</th>
            <th>Average</th>
        </tr>
        <?php $rank = 1; while ($row = $best_avg->fetch_assoc()) { ?>
        <tr>
            <td><b><?php echo $rank++; ?></b></td>
            <td><?php echo $row['player_name']; ?></td>
            <td><?php echo $row['team_name']; ?></td>
            <td><span class="role-badge role-<?php echo $row['role']; ?>"><?php echo $row['role']; ?></span></td>
            <td><?php echo $row['runs_scored']; ?></td>
            <td><?php echo $row['matches_played']; ?></td>
            <td><b><?php echo $row['avg_runs']; ?></b></td>
        </tr>
        <?php } ?>
    </table>
<?php } ?>

<!-- Players per team -->
<h3 class="page-subtitle">Squad Size by Team</h3>
<table class="data-table">
    <tr>
        <th>Team</th>
        <th>Total Players</th>
    </tr>
    <?php while ($row = $team_counts->fetch_assoc()) {
        $words = explode(" ", $row['team_name']);
        $initials = "";
        foreach ($words as $w) { $initials .= substr($w, 0, 1); }
    ?>
    <tr>
        <td>
            <span class="team-logo" style="background-color: <?php echo $row['logo_color']; ?>">
                <?php echo $initials; ?>
            </span>
            <?php echo $row['team_name']; ?>
        </td>
        <td><?php echo $row['total_players']; ?> players</td>
    </tr>
    <?php } ?>
</table>

<?php
$conn->close();
include 'includes/footer.php';
?>
