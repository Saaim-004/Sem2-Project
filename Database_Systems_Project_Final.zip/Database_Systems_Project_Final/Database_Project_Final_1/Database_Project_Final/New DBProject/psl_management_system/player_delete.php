<?php


include 'includes/auth_check.php';
include 'includes/connect.php';

$player_id = (int) $_GET['id'];

$sql = "DELETE FROM players WHERE player_id = $player_id";

if ($conn->query($sql) === TRUE) {
    header("Location: players.php?msg=Player deleted successfully!");
    exit();
} else {
    echo "Could not delete player: " . $conn->error;
    echo '<br><a href="players.php">Back to Players</a>';
}

$conn->close();
?>
