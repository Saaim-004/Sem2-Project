<?php

include 'includes/connect.php';

$total_teams   = $conn->query("SELECT COUNT(*) AS c FROM teams")->fetch_assoc()['c'];
$total_players = $conn->query("SELECT COUNT(*) AS c FROM players")->fetch_assoc()['c'];
$total_matches = $conn->query("SELECT COUNT(*) AS c FROM matches")->fetch_assoc()['c'];
$played_matches = $conn->query("SELECT COUNT(*) AS c FROM matches WHERE winner_id IS NOT NULL")->fetch_assoc()['c'];

$top_teams_sql = "SELECT t.team_name, t.logo_color, p.matches_played, p.wins,
                         (p.matches_played - p.wins) AS losses,
                         (p.wins * 2) AS points
                  FROM points p
                  INNER JOIN teams t ON p.team_id = t.team_id
                  ORDER BY (p.wins * 2) DESC, p.wins DESC
                  LIMIT 3";
$top_teams = $conn->query($top_teams_sql);

$recent_sql = "SELECT m.match_date, m.result_margin,
                      t1.team_name AS team1_name, t1.logo_color AS team1_color,
                      t2.team_name AS team2_name, t2.logo_color AS team2_color,
                      w.team_name AS winner_name
               FROM matches m
               INNER JOIN teams t1 ON m.team1_id = t1.team_id
               INNER JOIN teams t2 ON m.team2_id = t2.team_id
               LEFT JOIN teams w ON m.winner_id = w.team_id
               WHERE m.winner_id IS NOT NULL
               ORDER BY m.match_date DESC
               LIMIT 4";
$recent_matches = $conn->query($recent_sql);
?>
<?php include 'includes/header.php'; ?>

<h2 class="page-title">Welcome to the PSL Team Management System</h2>
<p>Manage Pakistan Super League teams, players, matches, and statistics from a single place.</p>

<div class="card-row mt-20">
    <div class="stat-card">
        <h3><?php echo $total_teams; ?></h3>
        <p>Teams</p>
    </div>
    <div class="stat-card">
        <h3><?php echo $total_players; ?></h3>
        <p>Players</p>
    </div>
    <div class="stat-card">
        <h3><?php echo $total_matches; ?></h3>
        <p>Total Matches</p>
    </div>
    <div class="stat-card">
        <h3><?php echo $played_matches; ?></h3>
        <p>Matches Played</p>
    </div>
</div>

<div class="two-col">
    <div>
        <h3 class="page-subtitle">Top of the Points Table</h3>
        <table class="data-table">
            <tr>
                <th>#</th>
                <th>Team</th>
                <th>P</th>
                <th>W</th>
                <th>L</th>
                <th>Pts</th>
            </tr>
            <?php
            $rank = 1;
            while ($row = $top_teams->fetch_assoc()) {
                // Get team initials for the logo badge
                $words = explode(" ", $row['team_name']);
                $initials = "";
                foreach ($words as $w) {
                    $initials .= substr($w, 0, 1);
                }
            ?>
            <tr>
                <td><?php echo $rank++; ?></td>
                <td>
                    <span class="team-logo" style="background-color: <?php echo $row['logo_color']; ?>">
                        <?php echo $initials; ?>
                    </span>
                    <?php echo $row['team_name']; ?>
                </td>
                <td><?php echo $row['matches_played']; ?></td>
                <td><?php echo $row['wins']; ?></td>
                <td><?php echo $row['losses']; ?></td>
                <td><b><?php echo $row['points']; ?></b></td>
            </tr>
            <?php } ?>
        </table>
        <p class="mt-20"><a href="points_table.php" class="btn btn-secondary">View Full Points Table</a></p>
    </div>

    <div>
        <h3 class="page-subtitle">Recent Matches</h3>
        <?php if ($recent_matches->num_rows == 0) { ?>
            <p class="text-muted">No matches have been played yet.</p>
        <?php } else { ?>
            <table class="data-table">
                <tr>
                    <th>Date</th>
                    <th>Match</th>
                    <th>Result</th>
                </tr>
                <?php while ($row = $recent_matches->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo date("d M Y", strtotime($row['match_date'])); ?></td>
                    <td><?php echo $row['team1_name']; ?> vs <?php echo $row['team2_name']; ?></td>
                    <td><?php echo $row['winner_name'] . ' won ' . $row['result_margin']; ?></td>
                </tr>
                <?php } ?>
            </table>
        <?php } ?>
        <p class="mt-20"><a href="matches.php" class="btn btn-secondary">View All Matches</a></p>
    </div>
</div>

<?php
$conn->close();
include 'includes/footer.php';
?>
