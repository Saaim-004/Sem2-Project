<?php


include 'includes/auth_check.php';
include 'includes/connect.php';

$team_id = (int) $_GET['id'];

$sql = "DELETE FROM teams WHERE team_id = $team_id";

if ($conn->query($sql) === TRUE) {
    header("Location: teams.php?msg=Team deleted successfully!");
    exit();
} else {
    echo "Could not delete team: " . $conn->error;
    echo '<br><a href="teams.php">Back to Teams</a>';
}

$conn->close();
?>
